.show_sp500monthly<-function(n=2){
"
  
  
  
  

  
"  ;.zshow_sp500monthly(n)}


.zshow_sp500monthly<-function(n){

    if(exists('.sp500monthly')==FALSE){
       .sp500monthly<<-read.csv("http://datayyy.com/data_csv/sp500monthly.csv")
   }
   .showNobs(.sp500monthly,n)
}