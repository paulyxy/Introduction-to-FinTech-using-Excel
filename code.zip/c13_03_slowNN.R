.showNN<-function(){
"Objective: show how a Neural Neworks works

 Example> # if layer=1, seed =123

error                           0.01367510
reached.threshold               0.00875548
steps                          52.00000000
Intercept.to.1layhid1          -4.99727565
StudyHours.to.1layhid1          4.86982251
ClassParticipation.to.1layhid1  6.65870831
Intercept.to.Target            -2.50829161
1layhid1.to.Target              5.22928774

  
  
";.zshowNN()}

.zshowNN<-function(){
  
    library(neuralnet)
  
    hitEnterKey<-function(){
         
         cat("*  hit the Enter Key to continue                       *\n")
         dummy<-readline()
    }
  
   cat(" * --------------------------------------------------- *\n")
   cat(" *  Objective: run a neural network for a data set     *\n")
   cat(" *        Choices: number of layers & a random seed    *\n")
#   hitEnterKey()
   
    # Step 1: Define the dataset
    data <- data.frame(
        StudyHours = c(5, 2, 8, 1),
        ClassParticipation = c(3, 1, 4, 0),
        Target = c(1, 0, 1, 0)
    )

    cat(" * --------------------------------------------------- *\n")
    cat(" *  Step 1: input the data  (as shown below)           *\n")
    cat(" * --------------------------------------------------- *\n")
    print(data,row.names=F)
    hitEnterKey()
    

    # Normalize the input features to a range of 0 to 1
   normalize <- function(x) {
        return((x - min(x)) / (max(x) - min(x)))
    }
   cat(" * --------------------------------------------------- *\n")
   cat(" *  Step 2: normalize varible 1 (study Hours)          *\n")
   cat(" * --------------------------------------------------- *\n")
   cat(" *   original values:")
   print(data$StudyHours,row.names=F)
   data$StudyHours <- normalize(data$StudyHours)
   cat(" *   new normalized values:")
   print(data$StudyHours,row.names=F)
   hitEnterKey()    
    
   cat(" * --------------------------------------------------- *\n")
   cat(" *  Step 2B: normalize class participation             *\n")
   cat(" * --------------------------------------------------- *\n")
   cat(" *   original values: ")
   print(data$ClassParticipation,row.names=F)
   data$ClassParticipation <- normalize(data$ClassParticipation)
   cat(" *   new normalized values:")
   print(data$ClassParticipation,row.names=F)
   hitEnterKey()    
   

   cat(" input the number of hidden layers, such as 2 \n")
   cat(" * --------------------------------------------------- *\n")
   nHiddenLayers<-as.numeric(readline())
   cat(" * --------------------------------------------------- *\n")
# Step 2: Define the neural network structure and train the model
# We'll use one hidden layer with two neurons
   
   cat(" input a random seed, such as 123\n")
   cat(" * --------------------------------------------------- *\n")
   seed<-as.numeric(readline())
   set.seed(seed)
  
  
nn <- neuralnet(Target ~ StudyHours + ClassParticipation, data = data, 
                hidden = nHiddenLayers,                 # Two neurons in the hidden layer
                act.fct = "logistic",       # Sigmoid activation function
                linear.output = FALSE,      # For binary output
                stepmax = 1e5)              # Maximum steps to train

# Step 3: Visualize the neural network structure

cat(" * --------------------------------------------------- *\n")
cat(" *  Print nn@result.matrix                             *\n")
cat(" * --------------------------------------------------- *\n")
print(nn$result.matrix)
plot(nn,lwd=2)

"
seed 123

                                     [,1]
error                           0.01367510
reached.threshold               0.00875548
steps                          52.00000000
Intercept.to.1layhid1          -4.99727565
StudyHours.to.1layhid1          4.86982251
ClassParticipation.to.1layhid1  6.65870831
Intercept.to.Target            -2.50829161
1layhid1.to.Target              5.22928774

"
#plot(nn,lwd=4)

# Step 4: Test the neural network with the same dataset
# Compute the output of the neural network for the input data
predictions <- compute(nn, data[, c("StudyHours", "ClassParticipation")])

# Step 5: Extract predicted values and round them to get binary output
predicted_values <- round(predictions$net.result)
print("Predicted Values (Pass = 1, Fail = 0):")
print(predicted_values)

# Optional: Check accuracy by comparing predictions to the target values
accuracy <- sum(predicted_values == data$Target) / nrow(data)
print(paste("Accuracy:", accuracy * 100, "%"))
}
  


# Install and load necessary package
#if (!require(neuralnet)) install.packages("neuralnet", dependencies = TRUE)
"
Explanation of the Code
Data Setup: We define the dataset in a data.frame with StudyHours,
ClassParticipation, and Target columns. The inputs are normalized 
to a range of 0–1 to aid training.

Neural Network Model: We use the neuralnet function to create a neural
network. The formula Target ~ StudyHours + ClassParticipation specifies
the input and target columns. We use one hidden layer with two neurons 
and apply the logistic (sigmoid) activation function.

Prediction and Accuracy: We test the model by making predictions on the 
training data and rounding outputs to get binary predictions 
(Pass = 1, Fail = 0). We then print the predicted values and
calculate the model's accuracy.

This program provides a basic example of implementing a simple neural
network with R and achieves a similar result to the manual setup in Excel.
"