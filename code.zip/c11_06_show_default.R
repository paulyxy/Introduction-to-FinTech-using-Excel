.show_default<-function(n=2){
"Objective: show the Heart Disease data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1> .show_default()
            default student  balance   income
          1      No      No 729.5265 44361.63
          2      No     Yes 817.1804 12106.13
          
 Exanoke 2> .show_default(-4)
           default student   balance   income
     9997       No      No  757.9629 19660.72
     9998       No      No  845.4120 58636.16
     9999       No      No 1569.0091 36669.11
    10000       No     Yes  200.9222 16862.95

 Example 3>.show_default(0)
          Windows users: launch Excel and paste

";.zshow_default(n)}

.zshow_default<-function(n){
      if(exists('.defaultData')==FALSE){
      infile<-"http://datayyy.com/data_R/default.RData"
      load(url(infile))
      .defaultData<<-.x
    }
  
    .showNobs(.defaultData,n)
}
