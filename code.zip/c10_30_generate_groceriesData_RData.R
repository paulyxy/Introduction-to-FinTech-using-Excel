


x<-read.csv("c://yan/teaching/i2ft/data/Groceries_dataset.csv")
.x<-x
save(.x,file='c://temp/groceriesData.RData')
