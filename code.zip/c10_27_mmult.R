..mmult<-function(){
"Objective: mimic Excel mmult() function 

> .mmult()
   * ------------------------------------------------------ *
   * Objective: mimic Excel mmult() function                *
   *               = mmult(A,B)                             *
   * ------------------------------------------------------ *
   * Step 1: Copy matrix A then hit the Enter Key           * 
   *         One example is shown below.                    *
   * ------------------------------------------------------ *
3   4   -2
1   4    1
2   6   -1

   * Step 2: Copy matrix B then hit the Enter Key           * 
   *         One example is shown below.                    *
   * ------------------------------------------------------ *
1   2   3
1   4   1
2   5   5

  * Step 3: Hit the Enter Key to get the final result       * 

     V1 V2 V3
[1,]  3 12  3
[2,]  7 23 12
[3,]  6 23  7
   * ------------------------------------------------------ *
";.zmmult()}

.zmmult<-function(){
  cat(" * ------------------------------------------------------ *\n")
  cat(" * Objective: mimic Excel mmult() function                *\n")
  cat(" *               = mmult(A,B)                             *\n")
  cat(" * ------------------------------------------------------ *\n")
  cat(' * Step 1: Copy matrix A then hit the Enter Key           * \n')
  cat(' *         One example is shown below.                    *\n')
  cat(" * ------------------------------------------------------ *\n")
  cat("3   4   -2\n")
  cat("1   4    1\n")
  cat("2   6   -1\n")
  dummy<-readline()
  A<-suppressWarnings(read.table("clipboard",header=F))
  a<-as.matrix(A)
  cat(' * Step 2: Copy matrix B then hit the Enter Key           * \n')
  cat(' *         One example is shown below.                    *\n')
  cat(" * ------------------------------------------------------ *\n")
  cat("1   2   3\n")
  cat("1   4   1\n")
  cat("2   5   5\n")
  dummy<-readline()
  B<-suppressWarnings(read.table("clipboard",header=F))
  b<-as.matrix(B)
  final<-a%*%b
  
  cat(' * Step 3: Hit the Enter Key to get the final result       * \n')
  dummy<-readline()
  print(final)
  cat(" * ------------------------------------------------------ *\n")
  
  
}