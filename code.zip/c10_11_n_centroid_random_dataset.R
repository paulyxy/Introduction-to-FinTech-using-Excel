.generateNcentroidsData<-function(){
"Objective: generate x, y for n centroids
    Example> .nCentroidsData()
            * ------------------------------------------------ *
            * Objective: generate a simulated data set with    *
            *            n such as 2,3,4,5 centroids           *
            * ------------------------------------------------ *
            * Step 1: input a random seed 
        123
            * Step 2: input the number of centroids            *
          3
            * Step 3: input the std, such as 0.5, 1, etc.      *
        0.5
            * Step 4: input the number of observations        * 
        100
           * ------------------------------------------------- *
           *   Launch Excel and pate your data there           *
           * ------------------------------------------------- *
" ;.zgenerateNcentroidsData()}
.nCentroidsData<<-.generateNcentroidsData

.zgenerateNcentroidsData<-function(){
  
  cat("   * ------------------------------------------------ *\n")
  cat("   * Objective: generate a simulated data set with    *\n")
  cat('   *            n such as 2,3,4,5 centroids           *\n')
  cat("   * ------------------------------------------------ *\n")
  cat("   * Step 1: input a random seed                      *\n")
  seed<-as.numeric(readline())
  set.seed(seed)
  
  cat("   * Step 2: input the number of centroids (2,3,4,5)  *\n")
  nCentroids<-as.numeric(readline())
  
  cat("   * Step 3: input the std, such as 0.5, 1, etc.      *\n")
  std<-as.numeric(readline())

  cat("   * Step 4: input the number of observations         *\n")
  n<-as.numeric(readline())
  
  
  if(nCentroids>=2 & nCentroids<=5){
       if(nCentroids==2){
           a<-rep(1:2, each =n)
           b<-rep(c(1, 2), each =n)
      }else if(nCentroids==3){
           a<-rep(1:3, each =n)
           b<-rep(c(1, 2,3), each =n)
      }else if(nCentroids==4){
           a<-rep(1:4, each =n)
           b<-rep(c(1, 2,3,4), each =n)
     }else{
          a<-rep(1:5, each =n)
          b<-rep(c(1, 2,3,4,5), each =n)
      }
  
      cat("   * ------------------------------------------------ *\n")
      data <- data.frame(
          x = rnorm(n, mean = a, sd =std),
          y = rnorm(n, mean = b, sd = std)
       )

     write.csv(data,file="clipboard",row.names=F,quote=F)
     cat("   *   Launch Excel and pate the data there           *\n")
     cat("   * ------------------------------------------------ *\n")

   # Apply k-means clustering
   #kmeans_result <- kmeans(data, centers =n)
   # Add cluster results to data
   #data$cluster <- as.factor(kmeans_result$cluster)
  }else{
    cat(" Error messnage:\n")
    cat("   The number of centroids should be 2,3,4 or 5        \n")
    
    
  }
}

