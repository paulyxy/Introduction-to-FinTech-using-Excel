.pcaExamples<-function(){
"Objective: show a few examples
 Example >.pcae()
        * ------------------------------------------------------------ *
        *  Objective: show a few examples                              *
        * ------------------------------------------------------------ *
        *  1           iris                                            *
        *  2           cars                                            *
        *  3           USArrests                                       *
        *  4           wine                                            *
        *  5           attitude                                        *
        *  Esc to exit                                                 *
        * ------------------------------------------------------------ *
        *  Enter your choice                                           *
    1
        * ------------------------------------------------------------ *
        *  The first and last 3 lines are shown below.                 *
        * ------------------------------------------------------------ *
         Sepal.Length Sepal.Width Petal.Length Petal.Width Species
       1          5.1         3.5          1.4         0.2  setosa
       2          4.9         3.0          1.4         0.2  setosa
       3          4.7         3.2          1.3         0.2  setosa
        Sepal.Length Sepal.Width Petal.Length Petal.Width   Species
     148          6.5         3.0          5.2         2.0 virginica
     149          6.2         3.4          5.4         2.3 virginica
     150          5.9         3.0          5.1         1.8 virginica
       * ------------------------------------------------------------ *
       * PCA result are given below.                                  *
       * ------------------------------------------------------------ *
       Importance of components:
                            PC1    PC2     PC3     PC4
       Standard deviation     1.7084 0.9560 0.38309 0.14393
       Proportion of Variance 0.7296 0.2285 0.03669 0.00518
       Cumulative Proportion  0.7296 0.9581 0.99482 1.00000
       * ------------------------------------------------------------ *
 ";.zpcaExamples()}

.pcae<<-.pcaExamples

.zpcaExamples<-function(){
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Objective: show a few examples                              *\n")  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  1           iris                                            *\n")
  cat(" *  2           cars                                            *\n")
  cat(" *  3           USArrests                                       *\n")
  cat(" *  4           wine                                            *\n")
  cat(" *  5           attitude                                        *\n")
  cat(" *  Esc to exit                                                 *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  
  i<-as.numeric(readline())
  
  if(i==1){
       data(iris)
       pca_result <- prcomp(iris[, -5], scale. = TRUE)
       .x<-iris
  }else if(i==2){
       data(mtcars)
       pca_result <- prcomp(mtcars, scale. = TRUE)
       .x<-mtcars
  }else if(i==3){
        data(USArrests)
        pca_result <- prcomp(USArrests, scale. = TRUE)
        .x<-USArrests
  }else if(i==4){
     load(url("http://datayyy.com/i2ft/data/wine.RData"))
     pca_result <- prcomp(wine[, -1], scale. = TRUE)
     .x<-wine
  }else {
      data(attitude)
      pca_result <- prcomp(attitude, scale. = TRUE)
      .x<-attitude
  }

  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  The first and last 3 lines are shown below.                 *\n")
  cat(" * ------------------------------------------------------------ *\n")
  print(head(.x,3))
  print(tail(.x,3))
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * PCA result are given below.                                  *\n")
  cat(" * ------------------------------------------------------------ *\n")
  a<-summary(pca_result)
  print(a)  
  cat(" * ------------------------------------------------------------ *\n")
}


#library(FactoMineR)
#pca_result <- PCA(iris[, -5], graph = FALSE)
