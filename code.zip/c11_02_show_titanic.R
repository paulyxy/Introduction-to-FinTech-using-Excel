.show_titanic<-function(n=2){
"Objective: show the Titanic data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1> .show_titanic()

 Example 2>.show_titanic(-3)

 Example 3>.show_titanics(0)
            Launch Excel and paste

  
";.zshow_titanic(n)}

.zshow_titanic<-function(n){

      if(exists('.titanicData')==FALSE){
      infile<-"http://datayyy.com/data_R/titanic.RData"
      load(url(infile))
      .titanicData<<-.x
    }
  
    .showNobs(.titanicData,n)
}
