.knn<-function(){
"Objective: run Knn for a few data set
            need two packages
             install.packages('caret')
             install.packages('class') 

Example >> .show_iris(1)
          sepal_length sepal_width petal_length petal_width       class
              1          5.1         3.5          1.4         0.2 Iris-setosa
          >.show_iris(0)
            Windows users: launch Excel and paste
          >.knn()
 
 * ------------------------------------------------------------ *
 * Step 2: Does your data set have a header?                   *
 * ------------------------------------------------------------ *
 *  1         yes                                               *
 *  2         no                                                *
1
 * ------------------------------------------------------------ *
 *  The first 3 observations are shown below.                   *
 * ------------------------------------------------------------ *
 sepal_length sepal_width petal_length petal_width       class
          5.1         3.5          1.4         0.2 Iris-setosa
          4.9         3.0          1.4         0.2 Iris-setosa
          4.7         3.2          1.3         0.2 Iris-setosa
 * ------------------------------------------------------------ *
 * Step 3: Which column is your classfication (classes)?        *
 * ------------------------------------------------------------ *
5
 * ------------------------------------------------------------ *
 * Step 4: enter a random seed such as 123                      *
 * ------------------------------------------------------------ *
 *  Enter your choice                                           *
123
 * ------------------------------------------------------------ *
 * Step 5: What is the proportion, such as 0.75, of your        *
 *         data will be used as training data                   *
 * ------------------------------------------------------------ *
 *  Enter your choice                                           *
0.75

Confusion Matrix and Statistics

                 Reference
Prediction        Iris-setosa Iris-versicolor Iris-virginica
  Iris-setosa              12               0              0
  Iris-versicolor           0              14              3
  Iris-virginica            0               0             10

Overall Statistics
               Accuracy : 0.9231          
                 95% CI : (0.7913, 0.9838)
    No Information Rate : 0.359           
    P-Value [Acc > NIR] : 2.419e-13       
                  Kappa : 0.884           
                                        
 Mcnemar's Test P-Value : NA              
Statistics by Class:
                     Class: Iris-setosa Class: Iris-versicolor Class: Iris-virginica
Sensitivity                      1.0000                 1.0000                0.7692
Specificity                      1.0000                 0.8800                1.0000
Pos Pred Value                   1.0000                 0.8235                1.0000
Neg Pred Value                   1.0000                 1.0000                0.8966
Prevalence                       0.3077                 0.3590                0.3333
Detection Rate                   0.3077                 0.3590                0.2564
Detection Prevalence             0.3077                 0.4359                0.2564
Balanced Accuracy                1.0000                 0.9400                0.8846
 * ------------------------------------------------------------ *
 *  Knn Model Performance:                                      *
 * ------------------------------------------------------------ *
 *      Accuracy:  0.9230769 
 *      Precision:  1 0.8235294 1 
 *      Recall:  1 1 0.7692308 
 *      F1 Score:  1 0.9032258 0.8695652 
 * ------------------------------------------------------------ *
" ;.zknn()}

.zknn<-function(){

library(caret)
library(class)   # For knn algorithm

  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Objective: run knn with your data                           *\n")  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 1: copy your Excel data  set, then hit the Enter Key    *\n")
  cat(" * ------------------------------------------------------------ *\n")
  dummy<-readline()
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 2: Does your data set have a header?                   *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  1         yes                                               *\n")
  cat(" *  2         no                                                *\n")
  yes<-readline()
  
  if(yes=='1'){
       data<-read.table('clipboard',header=T)
  }else{
       data<-read.table('clipboard')
  }
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  The first 3 observations are shown below.                   *\n")
  cat(" * ------------------------------------------------------------ *\n")
   print(head(data,3),row.names=F)
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 3: Which column is your classfication (classes)?        *\n")
  cat(" * ------------------------------------------------------------ *\n")
  columnClass<-as.numeric(readline())
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 4: enter a random seed such as 123                      *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  seed<-as.numeric(readline())
  set.seed(seed)
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 5: What is the proportion, such as 0.75, of your        *\n")
  cat(" *         data will be used as training data                   *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  p<-as.numeric(readline())

n<-nrow(data)
a<-runif(n)

#p<-0.75
#trainIndex<-a>1-p
#trainData <- data[trainIndex, ]
#testData <-  data[-trainIndex, ]

data$random<-a
trainData <- data[data$random>=1-p, ]
testData <-  data[data$random<1-p, ]


# Prepare training and testing sets
trainX <- trainData[, -columnClass]  # Training features (without the species column)
trainX<-trainX[ , -which(names(trainX) %in% c("random"))]

trainY <- trainData[,  columnClass]

testX <- testData[, -columnClass]     # Testing features (without the species column)
testX<- testX[ , -which(names(testX) %in% c("random"))]

testY <- testData[,  columnClass]    # Testing labels

# Apply k-NN algorithm (k = 3 is used here, but you can adjust)
cat(" * ------------------------------------------------------------ *\n")
cat(" * Step 6:Input k value such as 3                               *\n")
myK <-as.numeric(readline())
predictedY <- knn(train = trainX, test = testX, cl = trainY, k = myK)

# Confusion matrix and performance metrics
#confusionMatrix <- confusionMatrix(predictedY, testY)
confusionMatrix <- confusionMatrix(factor(predictedY), factor(testY))

# Output the results
print(confusionMatrix)

# Additional metrics
accuracy <- confusionMatrix$overall['Accuracy']
#precision <- confusionMatrix$byClass['Pos Pred Value']
precision <- confusionMatrix$byClass[,3]
#recall <- confusionMatrix$byClass['Sensitivity']
recall <- confusionMatrix$byClass[,1]
f1_score <- 2 * ((precision * recall) / (precision + recall))

cat(" * ------------------------------------------------------------ *\n")
cat(" *  Knn Model Performance:                                      *\n")
cat(" * ------------------------------------------------------------ *\n")
cat(" *      Accuracy: ", accuracy, "\n")
cat(" *      Precision: ", precision, "\n")
cat(" *      Recall: ", recall, "\n")
cat(" *      F1 Score: ", f1_score, "\n")
cat(" * ------------------------------------------------------------ *\n")
}