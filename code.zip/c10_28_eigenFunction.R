.eigen<-function(){
"Objective: generate eigen vectors and values

Example > .eigen()

3 4 -2
1 4  1
2 6 -1



2.5	2.4	3.5
0.5	0.7	1
2.2	2.9	3.1
1.9	2.2	2.9
3.1	3	4.1


";.zeigen()}

.zeigen<-function(){

  cat(" * ---------------------------------------------------------------- *\n")
  cat(" * Objective: generrate eigen vectors and values                    *\n")
  cat(" * ---------------------------------------------------------------- *\n")
  cat(" *  Copy yoru matrix then hit the Enter Key                         *\n")
  cat(" *    one example is hown below.                                    *\n")
  cat(" * ---------------------------------------------------------------- *\n")
  cat("3 4 -2\n")
  cat("1 4  1\n")
  cat("2 6 -1\n")
  
  #cat("2.5	2.4	3.5\n")
  #cat()"0.5	0.7	1\n")
  #cat(2.2	2.9	3.1
  #1.9	2.2	2.9
  #3.1	3	4.1
  
  dummy<-readline()

A<-suppressWarnings(read.table("clipboard",header=FALSE))
cat(" * ---------------------------------------------------------------- *\n")
cat(" *  Your input is shown below.                                      *\n")
cat(" * ---------------------------------------------------------------- *\n")
print(A,rows.name=F)
cat(" * ---------------------------------------------------------------- *\n")
#a<-eigen(A)

std<-apply(A,2,sd)
m<-apply(A,2,mean)
A2<-(A-m)/std
myCov<-cov(A2,A2)
a<-eigen(myCov)


cat(" *  Eigen values are shown below.                                   *\n")
cat(" * ---------------------------------------------------------------- *\n")
print(a[1])
cat(" *  Eigen vectors are shown below.                                   *\n")
print(a[2])
cat(" * ---------------------------------------------------------------- *\n")

}


