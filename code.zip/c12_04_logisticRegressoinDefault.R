.logisticRegressionDefault<-function(){
"

  
";.zlogisticRegressionDefault()}


.lrDefault<<-.logisticRegressionDefault


.zlogisticRegressionDefault <- function(){
  
 library(clipr)
  
  cat(" * ----------------------------------------------- *\n")
  cat(" * Objective: run a logistic regression            *\n")

  cat(" * ----------------------------------------------- *\n")
  cat(" * Step 1: copy your data then hit the Enter Key   *\n")
  
  dummy<-readline()
  data<-read_clip_tbl()
    
  # Load data
  data <- ISLR::Default
  
  cat(" * ----------------------------------------------- *\n")
  cat(" * Step 2: enter a random seed, such as 123        *\n")
  seed <- as.numeric(readline())
  set.seed(seed)
  
  cat(" * ----------------------------------------------- *\n")
  cat(" * Step 3: enter a value for training such as 0.7  *\n")
  p <- as.numeric(readline())
  
  # Split data into training and testing sets
  sample <- sample(c(TRUE, FALSE), nrow(data), replace = TRUE, prob = c(p, 1 - p))
  train <- data[sample, ]
  test <- data[!sample, ]  
  
  # Fit logistic regression model
  model <- glm(default ~ student + balance + income, family = "binomial", data = train)
  
  options(scipen = 999) # Disable scientific notation for model summary
  summary(model)      # View model summary
  
  cat(" * ----------------------------------------------- *\n")
  cat(" * Step 4: Generating predictions and confusion matrix\n")
  
  # Generate predictions for the test set
  test$predicted_prob <- predict(model, newdata = test, type = "response")
  
  # Convert probabilities to class predictions (default = "Yes" if prob > 0.5)
  test$predicted_class <- ifelse(test$predicted_prob > 0.5, "Yes", "No")
  
  # Create a confusion matrix
  actual <- test$default
  predicted <- factor(test$predicted_class, levels = levels(actual))
  confusion_matrix <- table(Predicted = predicted, Actual = actual)
  
  print(confusion_matrix)
  
  # Calculate accuracy, sensitivity, and specificity
  accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
  cat("Accuracy:", round(accuracy, 4), "\n")
  
  sensitivity <- confusion_matrix["Yes", "Yes"] / sum(confusion_matrix[, "Yes"])
  specificity <- confusion_matrix["No", "No"] / sum(confusion_matrix[, "No"])
  
  cat("Sensitivity (True Positive Rate):", round(sensitivity, 4), "\n")
  cat("Specificity (True Negative Rate):", round(specificity, 4), "\n")
}


