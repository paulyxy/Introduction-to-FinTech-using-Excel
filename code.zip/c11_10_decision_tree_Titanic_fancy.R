.decisionTree_titanic<-function(){
"Objective: Draw a decision tree based on the Titanic data set
    install.packages('rpart')

" ;.zdecisionTree_titanic()}
  
.dtTitanic<<-.decisionTree_titanic

.zdecisionTree_titanic<-function(){
  

  cat(" * ------------------------------------------------------ *\n")
  cat(" * Objective: draw a fancy decision tree for              *\n")
  cat(" *           using the Titanic data set                   *\n")
  cat(" * ------------------------------------------------------ *\n")
  cat(" *    Hit the enter key to continue")
  dummy<-readline()
  
  load(url("http://datayyy.com/data_R/titanic.RData"))
  ds     <- .x
  
  cat(" * ------------------------------------------------------ *\n")
  cat(" *    Do you want to print the first 3 lines?             *\n")
  cat(" * ------------------------------------------------------ *\n")
  cat(" *   1   for yes                                          *\n")
  cat(" *   2   for yes                                          *\n")
  yes<-readline()
  if(yes=="1"){
    print(head(ds,3))    
  }
  
  
  library(rpart)
  cat(" * ------------------------------------------------------ *\n")
  cat(' *   input a random seed, such as 123                     *\n')
  cat(" * ------------------------------------------------------ *\n")
  seed<-as.numeric(readline())
  
   set.seed(seed)
   
   target <- "Survived"
   
   names<-colnames(.x)
   ignore<-c("PassengerId")
   vars<-setdiff(names,ignore)
      nobs   <- nrow(ds)
   form   <- formula(paste(target, "~ ."))

   train  <- sample(nobs, 0.7*nobs)
   test   <- setdiff(seq_len(nobs), train)

   actual <- ds[test, target]
  # risks  <- ds[test, risk]
# Fit the model.

    fit <- rpart(form, data=ds[train, vars])
    fancyRpartPlot(fit)
}
