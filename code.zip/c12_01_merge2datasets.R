.merge2datasets<-function(){
"Objective
     install.packages('clipr')
  Example> .show_ibmMonthly(0)
           .show_ff3monthly(0)
           .merge()
  

    ";.zmerge2datasets()}

.merge<<-.merge2datasets

.zmerge2datasets<-function(){

  
  cat(" * --------------------------------------------------- *\n")
  cat(" * Objective: merge two data sets                      *\n")
  cat(" *         1) assumee 'clipr' was install, otherwize   *\n")
  cat(" *              install.packages('clipr')              *\n")
  cat(" *         2) both sets have a column called 'date'    *\n")

   if("clipr" %in% .packages(all.available=T)!=TRUE){
     cat(" * --------------------------------------------------- *\n")
     cat(" * Please install an R pcakage called 'clipr'          *\n")
     cat(" *    Copy/paste the following line to your R console  *\n")
     cat(" *        install.packages('clipr')                    *\n")
     cat(" * --------------------------------------------------- *\n")       
   }else{
      library(clipr)
  
     cat(" * --------------------------------------------------- *\n")
  cat(" *  Step 1:  Copy data set #1 then hit the Enter Key   *\n")
  dummy<-readline()
  #x<-read.table("clipboard",header=T)
  
  x<-read_clip_tbl()
  colnames(x)<-toupper(colnames(x))
  
  cat(" * --------------------------------------------------- *\n")
  cat(" *  Step 2:  Copy data set #2 then hit the Enter Key   *\n")
  dummy<-readline()
  #y<-read.table("clipboard",header=T)
  y<-read_clip_tbl()
  colnames(y)<-toupper(colnames(y))
  
  cat(" * --------------------------------------------------- *\n")
  cat(" *  Step 3:  launch Excel and paste it there           *\n")
  
  z<-merge(x,y,by='DATE')
  write_clip(z)
  
  #Warning message:
    #In utils::write.table(z, file = "clipboard", col.names = NA, sep = ",",  :
     #                       clipboard buffer is full and output lost
   } 
  
 
}