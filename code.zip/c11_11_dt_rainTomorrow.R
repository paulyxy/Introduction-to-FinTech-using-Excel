.decisioniTree_rainTomorrow<-function(){
"
  
  
" ;.zdecisioniTree_rainTomorrow()}
  
.rainTomorrow<<-.decisioniTree_rainTomorrow

.zdecisioniTree_rainTomorrow<-function(){
  
   library(rpart)
  cat(' *   input a random seed                        \n')
  seed<-as.numeric(readline())
  
   set.seed(seed)
   ds     <- weather
   target <- "RainTomorrow"
   risk   <- "RISK_MM"
   ignore <- c("Date", "Location", risk)
   vars   <- setdiff(names(ds), ignore)
   nobs   <- nrow(ds)
   form   <- formula(paste(target, "~ ."))
   train  <- sample(nobs, 0.7*nobs)
   test   <- setdiff(seq_len(nobs), train)

   actual <- ds[test, target]
   risks  <- ds[test, risk]
# Fit the model.

    fit <- rpart(form, data=ds[train, vars])
    fancyRpartPlot(fit)
}
