.knnExamples<-function(){
"Objective: run Knn for a few data set
            need two packages
             install.packages('caret')
             install.packages('class') 
             
             
             
             
             
             
             

" ;.zknnExamples()}

.knne<<-.knnExamples

.zknnExamples<-function(){

library(caret)
library(class)   # For knn algorithm

  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Objective: a few examples for Knn (K Nearest Neighbors)     *\n")  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *   Hit the Enter Key to continue                              *\n")
  
  dummy<-readline()
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 1: choose a data set                                    *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  1           iris                                            *\n")
  cat(" *  2           cars                                            *\n")
  cat(" *  3           USArrests                                       *\n")
  cat(" *  4           wine                                            *\n")
  cat(" *  5           attitude                                        *\n")
  cat(" *  Esc to exit                                                 *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  
  i<-as.numeric(readline())
  
  if(i==1){
    data(iris)
    .x<-iris
  }else if(i==2){
    data(mtcars)
    .x<-mtcars
  }else if(i==3){
    data(USArrests)
    .x<-USArrests
  }else if(i==4){
    load(url("http://datayyy.com/i2ft/data/wine.RData"))
    .x<-wine
  }else {
    data(attitude)
    .x<-attitude
  }
  

  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 2: enter a random seed such as 123                      *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  seed<-as.numeric(readline())
  set.seed(seed)
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 3: enter a value such as 0.75 to deviding the original  *\n")
  cat(" *         into trading and testing sample (75% vs. 25%)       *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  p<-as.numeric(readline())
  
  

n<-nrow(.x)
a<-runif(n)

#p<-0.75
trainIndex<-a>1-p
trainData <- .x[trainIndex, ]
testData <-  .x[-trainIndex, ]

# Prepare training and testing sets
trainX <- trainData[, -5]  # Training features (without the species column)
trainY <- trainData$Species # Training labels

testX <- testData[, -5]     # Testing features (without the species column)
testY <- testData$Species    # Testing labels

# Apply k-NN algorithm (k = 3 is used here, but you can adjust)
k <- 3
predictedY <- knn(train = trainX, test = testX, cl = trainY, k = k)

# Confusion matrix and performance metrics
confusionMatrix <- confusionMatrix(predictedY, testY)

# Output the results
print(confusionMatrix)

# Additional metrics
accuracy <- confusionMatrix$overall['Accuracy']
#precision <- confusionMatrix$byClass['Pos Pred Value']
precision <- confusionMatrix$byClass[,3]
#recall <- confusionMatrix$byClass['Sensitivity']
recall <- confusionMatrix$byClass[,1]
f1_score <- 2 * ((precision * recall) / (precision + recall))

cat(" * ------------------------------------------------------------ *\n")
cat(" *  Knn Model Performance:                                      *\n")
cat(" * ------------------------------------------------------------ *\n")
cat(" *      Accuracy: ", accuracy, "\n")
cat(" *      Precision: ", precision, "\n")
cat(" *      Recall: ", recall, "\n")
cat(" *      F1 Score: ", f1_score, "\n")
cat(" * ------------------------------------------------------------ *\n")
}