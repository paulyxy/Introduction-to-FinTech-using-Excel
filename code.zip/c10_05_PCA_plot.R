# Load necessary library
library(ggplot2)

# Generate some sample data
set.seed(789)
data <- data.frame(
  x1 = rnorm(100, mean = rep(1:3, each = 50), sd = 0.5),
  x2 = rnorm(100, mean = rep(c(1, 2, 3), each = 50), sd = 0.5),
  x3 = rnorm(100, mean = rep(c(1, 2, 3), each = 50), sd = 0.5)
)

# Perform PCA
pca_result <- prcomp(data, scale. = TRUE)

# Convert PCA result to data frame for plotting
pca_data <- as.data.frame(pca_result$x)
pca_data$cluster <- as.factor(kmeans(pca_result$x, centers = 3)$cluster)

# Plot PCA result
ggplot(pca_data, aes(PC1, PC2, color = cluster)) +
  geom_point(size = 3) +
  ggtitle("PCA with K-Means Clustering")


