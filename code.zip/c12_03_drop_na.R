.drop_na<-function(){
"Objective: drop NA from your data set. The function needs two package.
            If not preinstelled, copy the following lines to your R console. 
                install.packages('tidyr')
                install.packages('clipr')
Example> 
           
           

";.zdrop_na()}


.zdrop_na<-function(){

  cat(" * ---------------------------------------------------- *\n")
  cat(" * Objective: drop NA from your data set. Assume that   *\n")
  cat(" *   'tidyrr' and 'clipr' were preinstalled, otherwize  *\n")
  cat(" *              install.packages('tidyr')               *\n")
  cat(" *              install.packages('clipr')               *\n")

  pass<-0
 
   if("tidyr" %in% .packages(all.available=T)!=TRUE){
      cat(" * --------------------------------------------------- *\n")
     cat(" * Please install an R pcakage called 'clipr'          *\n")
     cat(" *    Copy/paste the following line to your R console  *\n")
     cat("install.packages('tidyr')                               \n")
     cat(" * --------------------------------------------------- *\n")       
   }else{
     pass<-1
   }
  
  if("clipr" %in% .packages(all.available=T)!=TRUE){
    cat(" * --------------------------------------------------- *\n")
    cat(" * Please install an R pcakage called 'clipr'          *\n")
    cat(" *    Copy/paste the following line to your R console  *\n")
    cat(" i nstall.packages('clipr')                            \n")
    cat(" * --------------------------------------------------- *\n")       
  }else{
    pass<-pass+1
  }
  
  if(pass==2){
       library(clipr)
       library(tidyr)
       cat(" * --------------------------------------------------- *\n")
       cat(" *  Step 1:  Copy data set then hit the Enter Key     *\n")
       dummy<-readline()
       x<-read_clip_tbl()
       y<-drop_na(x)
  
       cat(" * --------------------------------------------------- *\n")
       cat(" *  Step 2:  launch Excel and paste it there           *\n")
       cat(" * --------------------------------------------------- *\n")
       write_clip(y)
  } 
 
}