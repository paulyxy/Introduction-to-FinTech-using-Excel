.knnPrediction<-function(){
"Objective: run Knn for a few data set
            need two packages
             install.packages('caret')
             install.packages('class') 
" ;.zknnPrediction()}


.knnPredict<<-.knnPrediction
.knnP<<-.knnPrediction

.zknnPrediction<-function(){

  library(caret)
  library(class)   # For knn algorithm

  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Objective: run knn with your data                           *\n")  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 1: copy your Excel data  set, then hit the Enter Key    *\n")
  cat(" * ------------------------------------------------------------ *\n")
  dummy<-readline()
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 2: Does your data set have a header?                   *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  1         yes                                               *\n")
  cat(" *  2         no                                                *\n")
  yes<-readline()
  
  if(yes=='1'){
       data<-read.table('clipboard',header=T)
  }else{
       data<-read.table('clipboard')
  }
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  The first 3 observations are shown below.                   *\n")
  cat(" * ------------------------------------------------------------ *\n")
   print(head(data,3),row.names=F)
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 3: Which column is your classfication (classes)?        *\n")
  cat(" * ------------------------------------------------------------ *\n")
  columnClass<-as.numeric(readline())
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 4: enter a random seed such as 123                      *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  seed<-as.numeric(readline())
  set.seed(seed)
  
  cat(" * ------------------------------------------------------------ *\n")
  cat(" * Step 5: What is the proportion, such as 0.75, of your        *\n")
  cat(" *         data will be used as training data                   *\n")
  cat(" * ------------------------------------------------------------ *\n")
  cat(" *  Enter your choice                                           *\n")
  p<-as.numeric(readline())

n<-nrow(data)
a<-runif(n)

data$random<-a
trainData <- data[data$random>=1-p, ]
testData <-  data[data$random<1-p, ]


# Prepare training and testing sets
trainX <- trainData[, -columnClass]  # Training features (without the species column)
trainX<-trainX[ , -which(names(trainX) %in% c("random"))]

trainY <- trainData[,  columnClass]

testX <- testData[, -columnClass]     # Testing features (without the species column)
testX<- testX[ , -which(names(testX) %in% c("random"))]

testY <- testData[,  columnClass]    # Testing labels



# Apply k-NN algorithm (k = 3 is used here, but you can adjust)
cat(" * ------------------------------------------------------------ *\n")
cat(" * Step 6:Input k value such as 3                               *\n")
myK <-as.numeric(readline())

cat(" * ------------------------------------------------------------ *\n")
cat(" * Step 7: input your x values                                  *\n")
cat(" *         e.g., for Iris                                       *\n")
cat("4.9 3.0 1.4 0.2\n")
cat(" * ------------------------------------------------------------ *\n")

testX<-c( 4.9,        3.0 ,        1.4 ,    0.2)
testx<-scan()
cat(" * ------------------------------------------------------------ *\n")
cat(" * Our prediction for x =",testX," is:\n")
output<-knn(train = trainX, test = testX, cl = trainY, k = myK)
print(output)
cat(" * ------------------------------------------------------------ *\n")

}