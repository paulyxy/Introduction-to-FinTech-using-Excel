.show_groceriesData<-function(n=2){
" Objective: show the IBM daily data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1 > .show_groceriesData()
            Member_number       Date itemDescription
          1          1808 21-07-2015  tropical fruit
          2          2552 05-01-2015      whole milk
          
 Example 2>.show_groceriesData(-3)
            Member_number       Date       itemDescription
     38763          1097 16-04-2014              cake bar
     38764          1510 03-12-2014 fruit/vegetable juice
     38765          1521 26-12-2014              cat food
 
 Example 3:>.show_groceriesData(0)
              Windows users: launch Excel and paste
 
";.zshow_groceriesData(n)}

.zshow_groceriesData<-function(n){
  
  if(exists('.groceriesData')==FALSE){
    .infile<-"http://datayyy.com/i2ft/data/groceriesData.RData"
    .groceriesData<<-get(load(url(.infile)))
  }
  .showNobs(.groceriesData,n)
}


