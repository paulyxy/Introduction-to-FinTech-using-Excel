Sub GenerateCentroidDataFromCells()
    Dim i As Integer
    Dim numPoints As Integer
    Dim centroid1 As Variant, centroid2 As Variant, centroid3 As Variant
    Dim xOffset As Double, yOffset As Double
    Dim ws As Worksheet
    Dim resultCol As Integer
    
    ' Set the worksheet to the current active sheet
    Set ws = ActiveSheet
    
    ' Read the number of points to generate from cell A4
    numPoints = ws.Cells(4, 1).Value
    
    ' Read centroids from cells A1:C3 (students enter these values)
    centroid1 = Array(ws.Cells(1, 1).Value, ws.Cells(1, 2).Value) ' X1, Y1 from A1:B1
    centroid2 = Array(ws.Cells(2, 1).Value, ws.Cells(2, 2).Value) ' X2, Y2 from A2:B2
    centroid3 = Array(ws.Cells(3, 1).Value, ws.Cells(3, 2).Value) ' X3, Y3 from A3:B3
    
    ' Set the start column for results (either column C or D)
    resultCol = 3 ' Column C = 3, Column D = 4 (adjust as needed)
    
    ' Clear previous generated data (but keep A1:B3)
    ws.Range(ws.Cells(1, resultCol), ws.Cells(1 + 3 * numPoints, resultCol + 2)).ClearContents
    
    ' Place headers for the generated data in the result columns
    ws.Cells(1, resultCol).Value = "X"
    ws.Cells(1, resultCol + 1).Value = "Y"
    ws.Cells(1, resultCol + 2).Value = "Centroid"
    
    ' Generate data for Centroid 1
    For i = 1 To numPoints
        xOffset = (Rnd - 0.5) * 4
        yOffset = (Rnd - 0.5) * 4
        ws.Cells(i + 1, resultCol).Value = centroid1(0) + xOffset
        ws.Cells(i + 1, resultCol + 1).Value = centroid1(1) + yOffset
        ws.Cells(i + 1, resultCol + 2).Value = "1"
    Next i
    
    ' Generate data for Centroid 2
    For i = 1 To numPoints
        xOffset = (Rnd - 0.5) * 4
        yOffset = (Rnd - 0.5) * 4
        ws.Cells(i + numPoints + 1, resultCol).Value = centroid2(0) + xOffset
        ws.Cells(i + numPoints + 1, resultCol + 1).Value = centroid2(1) + yOffset
        ws.Cells(i + numPoints + 1, resultCol + 2).Value = "2"
    Next i
    
    ' Generate data for Centroid 3
    For i = 1 To numPoints
        xOffset = (Rnd - 0.5) * 4
        yOffset = (Rnd - 0.5) * 4
        ws.Cells(i + 2 * numPoints + 1, resultCol).Value = centroid3(0) + xOffset
        ws.Cells(i + 2 * numPoints + 1, resultCol + 1).Value = centroid3(1) + yOffset
        ws.Cells(i + 2 * numPoints + 1, resultCol + 2).Value = "3"
    Next i
    
    MsgBox "Data Generated!"
End Sub
