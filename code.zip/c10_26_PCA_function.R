.pca<-function(){
"Objective: generate the result by applying PCA
Example:> .pca()
        * ---------------------------------------------------------- *
        * Objective: apply PCA (Pricipal Component Analysis) method  *
        * ---------------------------------------------------------- *
        *   copy your data from Excel then hit the Enter Key         *
        *        e.g., you can copy the following three lines        *
        * ---------------------------------------------------------- *
1 2 4
4 1 2
5 4 8

     * ---------------------------------------------------------- *
     Standard deviations (1, .., p=3):
     [1] 1.508529e+00 8.510817e-01 8.588684e-18

   Rotation (n x k) = (3 x 3):
           PC1       PC2        PC3
   V1 0.4215374 -0.906811  0.0000000
   V2 0.6412122  0.298072 -0.7071068
   V3 0.6412122  0.298072  0.7071068
   * ------------------------------------------------------- *
";.zpca()}

.zpca<-function(){
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Objective: apply PCA (Pricipal Component Analysis) method  *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat(" *   Copy your data from Excel then hit the Enter Key         *\n")
  cat(" *        e.g., you can copy the following three lines        *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat("1 2 4\n")
  cat("4 1 2\n")
  cat("5 4 8\n\n")
  
  dummpy<-readline()
  A<-suppressWarnings(read.table("clipboard",header=F))
  
  
  pca_result <- prcomp(A, scale. = TRUE)
  cat(" * ---------------------------------------------------------- *\n")
  print(pca_result)
  cat(" * ---------------------------------------------------------- *\n")
  
  cat(" * Do you want to print PCA components?                       *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat(" *  1    yes\n")
  cat(" *  2    no\n")
  yes<-readline()
  
  if(yes=="1"){
     pca_components <- pca_result$x
     print(pca_components)
     write.csv(pca_components,file="clipboard")
     cat(" * Note; you can paste it to Excel                         *\n")
  }
 
   cat(" * Do you want to print the combined data?                     *\n")
   cat("              (the original data and PCA components)           *\n")
   cat(" * ----------------------------------------------------------- *\n")
   cat(" *  1    yes\n")
   cat(" *  2    no\n")
   yes2<-readline()
   if(yes2=="1"){
           combined <- cbind(A, pca_components)
           print(combined)
           write.csv(combined,file="clipboard")
           cat(" * Note; you can paste it to Excel                         *\n")
    }
}

