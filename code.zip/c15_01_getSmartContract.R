.getSmartContract <- function(hash) {
 "Objective: get the Smart Contract source code for a given hash

 
 
 
 Verify at  https://etherscan.io/contractsVerified

";.zgetSmartContract()}

.gsc<<-.getSmartContract


.zgetSmartContract <- function(hash) {
  # Objective: get the Smart Contract source code for a given hash
  
  cat(' * ----------------------------------------------------- *\n')
  cat(" *    Copy the hash of a given Smart contract            *\n")
  cat(" *             then hit the Enter Key to continue        *\n")
  cat(" *         a few examples are given below                *\n")
  cat(' * ----------------------------------------------------- *\n')
  cat(" *         0x4B0f06f7c0AFF32572D254c01aAfAfD6C51E4d52    *\n")
  cat(" *         0x475a86934805eF2C52EF61A8FED644D4C9AC91d8    *\n")
  cat(" *         0x9bEC821a885a6F4F8D4F0590DbdB315252c47302    *\n")
  cat(" * ----------------------------------------------------- *\n")
  
  dummy <- readline("Paste the contract hash: ")
  
  hash <- gsub(" ", "", dummy)  # Remove any accidental spaces in the input
  
  # Etherscan URL to fetch the smart contract code
  url <- paste0("https://etherscan.io/address/", hash, "#code")
  #https://etherscan.io/address/0x4B0f06f7c0AFF32572D254c01aAfAfD6C51E4d52#code
  
  # Read the HTML content
  html_content <- readLines(url, warn = FALSE)
  
  # Extract the portion that contains the smart contract code using specific HTML markers
  #code_start <- grep("<pre class='js-sourcecopyarea'>", html_content)
  
  code_start <- grep("Contract Source Code", html_content)
  #code_end <- grep("</pre>", html_content)
   code_end<-grep("Contract Security Audit", html_content)
  
 
  # Ensure that we found the start and end of the code
  if (length(code_start) > 0 && length(code_end) > 0) {
    # Extract the code from the HTML
    
    
    n1<-length(code_start)
    n2<-length(code_end)
    smart_contract_code <- html_content[code_start[1]:code_end[n2]]
    
    # Clean up the HTML tags
    smart_contract_code <- gsub("<[^>]*>", "", smart_contract_code)
    
    # Print the cleaned smart contract code
    #cat(smart_contract_code, sep = "\n")
    cat(smart_contract_code, sep = "\n",file="clipboard")
    cat(" *    Launch your text editor and paste the smart contract \n")
    
    
    } else {
    cat("Smart contract code could not be extracted. Please check the hash.\n")
  }
}



