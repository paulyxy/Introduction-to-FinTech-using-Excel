# Load necessary libraries
library(fpc)
library(ggplot2)

# DBSCAN (Density-Based Spatial Clustering of Applications 
# with Noise) clusters data points based on density.


# Generate some sample data
set.seed(101)
data <- data.frame(
  x = c(rnorm(50, mean = 1), rnorm(50, mean = 5)),
  y = c(rnorm(50, mean = 1), rnorm(50, mean = 5))
)

# Apply DBSCAN
dbscan_result <- dbscan(data, eps = 0.8, MinPts = 5)

# Add cluster results to data
data$cluster <- as.factor(dbscan_result$cluster)

# Plot the DBSCAN result
ggplot(data, aes(x, y, color = cluster)) +
  geom_point(size = 3) +
  ggtitle("DBSCAN Clustering")
