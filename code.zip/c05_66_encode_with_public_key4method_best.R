.encodeWithPublicKey <- function() {
  "Objective: Code your message with a public key
    one pair of public/private keys
    https://datayyy.com/fin136/data/public1key.pem.txt
    https://datayyy.com/fin136/data/private1key.pem.txt
    
    Example #1: Copy the public key at
    https://datayyy.com/fin136/data/public1key.pem.txt
    .en7()
    This is a great idea!
    
    Launch notepad and paste it there. 
  "; .zencodeWithPublicKey()
}

.en7 <<- .encodeWithPublicKey

.zencodeWithPublicKey <- function() {
  
  library(openssl)
  
  # Read the secret message from user input
  cat("\n")
  cat(' * -------------------------------------------------------- \n')
  cat(" *  Encrypt your message with a public key         \n")
  cat(" *    One pair of keys is given below               \n")
  cat(" *    public   https://datayyy.com/fin136/data/public1key.pem.txt\n")
  cat(" *    private  https://datayyy.com/fin136/data/private1key.pem.txt\n")
  cat(' * -------------------------------------------------------- \n')
  cat(" * Enter your secret message below:       \n")
  message <- readline()
  
  # Prompt the user to choose input method
  cat("\n")
  cat(" * 1      to input the public key manually \n")
  cat(" * 2      to provide a URL\n")
  cat(" * 3      from a local file\n")
  cat(" * 4      from a QR code (URL or local file)\n")
  input_method <- readline()
  
  if (input_method == '1') {
    # Method 1: Manually input the public key
    cat("\nEnter the public key below (finish with an empty line):\n")
    
    # Initialize an empty string to store the public key
    public_key_input <- ""
    repeat {
      line <- readline()
      if (line == "") break
      public_key_input <- paste0(public_key_input, line, "\n")
    }
  } else if (input_method == '2') {
    # Method 2: Read public key from a URL
    cat("\nEnter the URL for the public key:\n")
    url <- readline()
    # Read the public key from the provided URL
    public_key_input <- readLines(url)
    
    # Collapse the vector of lines into a single string
    public_key_input <- paste(public_key_input, collapse = "\n")
  } else if (input_method == '3') {
    # Method 3: Read public key from a local file
    infile <- file.choose()
    # Read the public key from the provided file
    public_key_input <- readLines(infile)
    
    # Collapse the vector of lines into a single string
    public_key_input <- paste(public_key_input, collapse = "\n")
  } else if (input_method == '4') {
    # Method 4: Read public key from a QR code (URL or local file)
    cat("\nTo use a QR code:\n")
    cat("1. Visit one of the following websites:\n")
    cat("   - https://www.qrstuff.com/scan\n")
    cat("   - https://zxing.org/w/decode.jspx\n")
    cat("2. Upload your QR code or provide the QR code URL\n")
    cat("3. Copy the decoded public key text\n\n")
    
    # Prompt user to enter the decoded public key manually
    cat("\nEnter the decoded public key below (finish with an empty line):\n")
    public_key_input <- ""
    repeat {
      line <- readline()
      if (line == "") break
      public_key_input <- paste0(public_key_input, line, "\n")
    }
  } else {
    stop("Invalid input method. Please enter '1', '2', '3', or '4'.")
  }
  
  # Save the public key input globally
  public_key_input <<- public_key_input
  
  # Convert the public key input to a public key object
  public_key <- read_pubkey(public_key_input)
  
  # Encrypt the message using the public key
  encrypted_message <- rsa_encrypt(charToRaw(message), public_key)
  a <- base64_encode(encrypted_message)
  
  # Output the encrypted message
  cat("Encrypted message:\n", a, "\n")
  
  # Optionally copy the encrypted message to the clipboard (for Windows)
  writeClipboard(a)
  cat(" \nLaunch a text editor, such as Notepad, and paste it there.\n\n")
  cat(' * -------------------------------------------------------- \n')
}
