.dtTitanicPlot<-function(){


 library(rpart)

 data(Titanic)
 data<-data.frame(Titanic)

 set.seed<-123



fit <- rpart(Survived ~ Pclass + Sex + Age + SibSp + Parch + Fare + Embarked,
             data=train,
             method="class")

}