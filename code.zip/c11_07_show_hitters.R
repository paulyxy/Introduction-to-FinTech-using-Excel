.show_hitters<-function(n=2){
"Objective: show the data set called 'Hitters'

Example 1> .show_hitters()
               AtBat Hits HmRun Runs RBI Walks Years CAtBat CHits CHmRun CRuns CRBI CWalks League Division PutOuts Assists
-Andy Allanson   293   66     1   30  29    14     1    293    66      1    30   29     14      A        E     446      33
-Alan Ashby      315   81     7   24  38    39    14   3449   835     69   321  414    375      N        W     632      43
               Errors Salary NewLeague
-Andy Allanson     20     NA         A
-Alan Ashby        10    475         N


Example 2> .show_hitters(-2)
               AtBat Hits HmRun Runs RBI Walks Years CAtBat CHits CHmRun CRuns CRBI CWalks League Division PutOuts Assists
-Willie Upshaw   573  144     9   85  60    78     8   3198   857     97   470  420    332      A        E    1314     131
-Willie Wilson   631  170     9   77  44    31    11   4908  1457     30   775  357    249      A        W     408       4
               Errors Salary NewLeague
-Willie Upshaw     12    960         A
-Willie Wilson      3   1000         A


Example 3> .show_hitters(0)
           Windows users: launch Excel and paste

";.zshow_hitters(n)}

.zshow_hitters<-function(n){
  
  if(exists('.hittersData')==FALSE){
    infile<-"http://datayyy.com/data_R/hitters.RData"
    .hittersData<<-get(load(url(infile)))
  }
  .showNobs(.hittersData,n)
}

