.clusterPlot<-function(){
"Objective: draw a k-mean

Example>  .kmeanPlot()
 
        * ------------------------------------------- *
        * Step 1: input a random seed 
        123
        * Step 2: input the number of centers 
        3
        * ------------------------------------------- *
  
" ;.zclusterPlot()}

.cPlot<<-.clusterPlot

.zclusterPlot<-function(){
  
  library(ggplot2)
  # Generate some sample data
  
  cat(" * ------------------------------------------- *\n")
  cat(" * Step 1: input a random seed \n")
  seed<-as.numeric(readline())
  set.seed(seed)
  cat(" * Step 2: input the number of centers \n")
  n<-as.numeric(readline())
  cat(" * ------------------------------------------- *\n")
    data <- data.frame(
      x = rnorm(100, mean = rep(1:3, each = 50), sd = 0.5),
      y = rnorm(100, mean = rep(c(1, 2, 3), each = 50), sd = 0.5)
   )

   # Apply k-means clustering
   kmeans_result <- kmeans(data, centers =n)
   # Add cluster results to data
   data$cluster <- as.factor(kmeans_result$cluster)

   # Plot the clusters
   ggplot(data, aes(x, y, color = cluster)) +
     geom_point(size = 3) +
     ggtitle("K-Means Clustering")
   
}


