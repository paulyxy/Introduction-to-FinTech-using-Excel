.show_airquality<-function(n=2){
" Objective: show the airquality data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1> .show_airquality()
           Ozone Solar.R Wind Temp Month Day
         1    41     190  7.4   67     5   1
         2    36     118  8.0   72     5   2

 Example 2> .show_airquality(-3)
          Ozone Solar.R Wind Temp Month Day
      151    14     191 14.3   75     9  28
      152    18     131  8.0   76     9  29
      153    20     223 11.5   68     9  30

 Example 3>.show_airquality(0)
            Launch Excel and paste

";.zshow_airquality(n)}

.zshow_airquality<-function(n){

  if(exists('.airqualityData')==FALSE){
         data(airquality)
        .airqualityData<<-airquality
  }

  .showNobs(.airqualityData,n)
}









