# Load necessary library
library(mclust)

# Generate some sample data
set.seed(111)
data <- data.frame(
  x = rnorm(100, mean = rep(1:3, each = 50), sd = 0.5),
  y = rnorm(100, mean = rep(c(1, 2, 3), each = 50), sd = 0.5)
)

# Apply GMM
gmm_result <- Mclust(data)

# Add cluster results to data
data$cluster <- as.factor(gmm_result$classification)

# Plot the GMM result
ggplot(data, aes(x, y, color = cluster)) +
  geom_point(size = 3) +
  ggtitle("Gaussian Mixture Model Clustering")
