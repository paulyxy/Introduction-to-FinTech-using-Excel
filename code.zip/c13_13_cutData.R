.cutData<-function(){
" Objective: cut a given data set into traing and testing

  Example> .show_iris(0)
           .cutData()


";.zcutData()}

.zcutData<-function(){
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Objective: cut a given data set into traing and testing    *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat(" *   Step 1:  Copy the data then hig the endter key           *\n")
  cat(" * ---------------------------------------------------------- *\n")
  dummy<-readline()
  x<-read.table("clipboard",header=T)

  
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 1b: [optional ]  print the first few lines?           *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat("  1         yes\n")
  cat("  2         yes\n")
  a<-readline()
  if(a=="1"){
         print(head(x))  
  }
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 2: input a seed such as 123                           *\n")
  cat(" * ---------------------------------------------------------- *\n")
  seed<-as.numeric(readline())
  set.seed(seed)
  
  n<-nrow(x)
  random<-runif(n)
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 2b: [ optional] do you wnat to copy the random        *\n")
  cat("            numbers to your Excel                             *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat("  1         yes\n")
  cat("  2         yes\n")
  a<-readline()
  if(a=="1"){
      write.csv(random,file="clipboard",row.names=F)
    cat(" * ---------------------------------------------------------- *\n")
    cat(" *  Paste the random numbers to Excel then enter key          *\n")
    cat(" * ---------------------------------------------------------- *\n")
    dummy<-readline()
  }
  
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 3: input a numer, such as 0.75, for the               *\n")
  cat("           proportion  use as traing sample                   *\n")
  cat(" * ---------------------------------------------------------- *\n")
  p<-as.numeric(readline())
  
  train<-x[random>1-p,]
  test<-x[random<=1-p,]
  
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 4: Paste the training data to Excel then              *\n")
  cat("           hit the Enter Key                                  *\n")
  cat(" * ---------------------------------------------------------- *\n")
  write.csv(train,file="clipboard")

  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 4b: [ optional] want to print a few lines of          *\n")
  cat("            the trading data set?                             *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat("  1         yes\n")
  cat("  2         yes\n")
  a<-readline()
  if(a=="1"){
       print(head(train))  
  }
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 5: Launch Excel and paste the training data           *\n")
  cat("           there then hit the Enter Key                       *\n")
  cat(" * ---------------------------------------------------------- *\n")
  write.csv(train,file="clipboard")
  
  cat(" * ---------------------------------------------------------- *\n")
  cat(" * Step 4b: [ optional] want to print a few lines of          *\n")
  cat("            the test  data set?                               *\n")
  cat(" * ---------------------------------------------------------- *\n")
  cat("  1         yes\n")
  cat("  2         yes\n")
  cat(" * ---------------------------------------------------------- *\n")
  a<-readline()
  if(a=="1"){
      print(head(test))
  }
}



