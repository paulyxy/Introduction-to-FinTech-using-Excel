.nn<-function(){
" Objective: run a neural networks from data set copied from Excel or clipboard
             install.packages('neuralnet')

 Example 1> .show_iris(0)
            .nn()
            
 Example 2:> ,show_default(0)    # using the raw data
             .nn()
              Error message:
                   your data has categorical variables     

 Example 2> .show_heartDisease(0)
            .nn()
";.znn()}

.znn<-function(){
  library(neuralnet)
  
  cat(rep("\n",50))

  cat(' * ---------------------------------------------------------------- *\n')
  cat(" *   Objective: run a Neural Network with a given data set          *\n")
  cat(' * ---------------------------------------------------------------- *\n')
  cat(" *  Step 1: copy your data then hit the enter key                   *\n")
  cat(' * ---------------------------------------------------------------- *\n')  
  dummy<-readline()
  #ds<-read.table('clipboard')
  cat(" *  Step 1B: Does your data set include a header?                   *\n")
  cat(" *   1      yes                                                     *\n")
  cat(" *   2      no                                                      *\n")
  yes<-readline()
  
  if(yes=="1"){
      ds<-read.table("clipboard",header=T)
  }else{
      ds<-read.table("clipboard")  
  }
  
   normalize <- function(x) {
       return((x - min(x)) / (max(x) - min(x)))
  }
  

 cat(" *   Step 1C: Do you want to print the first three lines?           *\n")
 cat(' * ---------------------------------------------------------------- *\n')
 cat("1    yes \n")
 cat("2    no  \n")
 a<-readline()

 if(a=="1"){
     print(head(ds,3),row.names=F)
   cat(' * ---------------------------------------------------------------- *\n')
 }
 
 cat(' * ---------------------------------------------------------------- *\n')
 cat(" *   Step 2: Which column is your target (class, default, etc.)     *\n")
 cat(' * ---------------------------------------------------------------- *\n')
 whichColumn<-as.numeric(readline())
 
   temp<-ds[,-whichColumn]
   n<-ncol(temp)
   noCategoricalColumn<-1 
   for(i in 1:n){
          a<-typeof(temp[,i])
          #print(a)
          if(a=="character"){
              noCategoricalColumn<-0
          }
   }
  #print(noCategoricalColumn)
 
  if(noCategoricalColumn==1){
      # before normalization 
      ourMax<-apply(ds[,-whichColumn],2,max)
      ourMin<-apply(ds[,-whichColumn],2,min)
      k<-data.frame(ourMax,ourMin)
      colnames(k)<-c("max","min")

      cat(' * ---------------------------------------------------------------- *\n')
      cat(" *   Paste the max and min values for several variables to Excel    *\n")
      cat(" *        then hit the Enter Key to continue                        *\n")
      cat(' * ---------------------------------------------------------------- *\n')
      write.csv(k,file="clipboard")
      dummy<-readline()
      cat(' * ---------------------------------------------------------------- *\n')    
      
      n<-ncol(ds)     # normalization !!!!!
      for(i in 1:n){
          if(i!=whichColumn){
              ds[,i]<-normalize(ds[,i])        
          }
      }

      cat(" *   Do you want to print 3 lines of the normalized observations    *\n")
      cat(" * ---------------------------------------------------------------- *\n")
      cat(" 1     yes \n")
      cat(" 2     no  \n")
      yes<-readline()
      if(yes=="1"){
          cat(" * ---------------------------------------------------------------- *\n")        
          print(head(ds,3),row.names=F)
          cat(" * ---------------------------------------------------------------- *\n")
      }
      
      cat(" *   Step 3: Enter a random seed for reproduction, such as 123      *\n")
      cat(' * ---------------------------------------------------------------- *\n')
      seed<-readline()
      set.seed(seed)

     #check categorical variable
     cat(" Step 4: input the number of hidden layers, such as 1 or 2          *\n")
     cat(' * ---------------------------------------------------------------- *\n')
     nHiddenLayers<-as.numeric(readline())

     names<-colnames(ds)
     target<-names[whichColumn]
     names<-names[-whichColumn]
     a<-toString((names))
     a<-gsub(","," +",a)
     #kk<-"class ~ sepal_length + sepal_width + petal_length + petal_width"
      kk<-paste(target,"~",a)
  
     nn <- neuralnet(kk,ds, hidden=nHiddenLayers,linear.output = FALSE)

    cat(' * ---------------------------------------------------------------- *\n')
    cat(" *   output matrix\n")
    cat(' * ---------------------------------------------------------------- *\n')
    write.csv(nn$result.matrix,file="clipboard")
    print(nn$result.matrix)
    cat(' * ---------------------------------------------------------------- *\n')
    cat(" *   Launch Excel and paste the result.matrix there.\n")
    cat(" *         then hit the Enter Key to view the graph\n")
    cat(' * ---------------------------------------------------------------- *\n')
    dummy<-readline()
    plot(nn)
 }else{
   cat(" * ---------------------------------------------------------------- *\n")
   cat(" Error message:                                                     *\n")
   cat("        Your data has categorical variables                         *\n")  
   cat(" * ---------------------------------------------------------------- *\n")
 }
 
}
 
