.showNN_iris2<-function(){
" Objective: show Neural Network using the IRIS data  
          using Petal.Length and Petal.Width
         install.packages('neuralnet')
  



  
"  ;.zshowNN_iris2()}




.zshowNN_iris2<-function(){
  library(neuralnet)
  data(iris)
# Binary classification

  # nn <- neuralnet(Species == "setosa" ~ Petal.Length + Petal.Width, iris, linear.output = FALSE)
  
  normalize <- function(x) {
       return((x - min(x)) / (max(x) - min(x)))
  }
  
  
  cat(' * ---------------------------------------------------------------- *\n')
  cat(" *   Objective: show Neural Network using the IRIS data             *\n")
  cat(" *              using 4 inputs instead of 2                         * \n")
  cat(' * ---------------------------------------------------------------- *\n')

data(iris)


 cat(" *   Do you want to print the first two lines?                      *\n")
 cat(' * ---------------------------------------------------------------- *\n')
 cat("1    yes \n")
 cat("2    no  \n")
 a<-readline()

 if(a=="1"){
     print(head(iris,2))
   cat(' * ---------------------------------------------------------------- *\n')
 }

 x<-iris

 x$Petal.Length <- normalize(x$Petal.Length)
 x$Petal.Width <- normalize(x$Petal.Width)
 
 x$Sepal.Length <- normalize(x$Sepal.Length)
 x$Sepal.Width<- normalize(x$Sepal.Width)
 
 cat(" *   Enter a random seed for reproduction, such as 123             *\n")
 cat(' * ---------------------------------------------------------------- *\n')
 seed<-readline()
 set.seed(seed)

 cat(' * ---------------------------------------------------------------- *\n')
 cat(" *   Which one you want to classify?\n")
 cat(' * ---------------------------------------------------------------- *\n')
 cat("1   setosa     \n")
 cat("2   versicolor \n")
 cat("3   virginica  \n")
 cat(' * ---------------------------------------------------------------- *\n')
 a<-readline()
 
 cat(" input the number of hidden layers, such as 1                        \n")
 cat(' * ---------------------------------------------------------------- *\n')
 nHiddenLayers<-as.numeric(readline())

   if(a=="1"){
          nn <- neuralnet(Species == "setosa" ~ Sepal.Length+Sepal.Width + Petal.Length + Petal.Width ,x, hidden=nHiddenLayers,linear.output = FALSE)
      
          
       #nn <- neuralnet("setosa" ~ Petal.Length + Petal.Width, data = iris,hidden = nHiddenLayers,
        #       act.fct = "logistic", linear.output = FALSE, stepmax = 1e5)              
       
      }else if(a=="2"){
   
       #     y<-"versicolor"
       nn <- neuralnet(Species == "versicolor" ~ Sepal.Length+Sepal.Width + Petal.Length + Petal.Width ,x, hidden=nHiddenLayers,linear.output = FALSE)
       
       #nn <- neuralnet("versicolor" ~ Petal.Length + Petal.Width, data = iris,hidden = nHiddenLayers,
                       #act.fct = "logistic", linear.output = FALSE, stepmax = 1e5)              
   }else{
      #y<-"virginica"
      nn <- neuralnet(Species == "virginica" ~ Sepal.Length+Sepal.Width + Petal.Length + Petal.Width ,x, hidden=nHiddenLayers,linear.output = FALSE)
      #nn <- neuralnet("virginica" ~ Petal.Length + Petal.Width, data = iris,hidden = nHiddenLayers,
       #               act.fct = "logistic", linear.output = FALSE, stepmax = 1e5)              
      
   }

 
 cat(' * ---------------------------------------------------------------- *\n')
 cat(" *   output matrix\n")
 cat(' * ---------------------------------------------------------------- *\n')
 write.csv(nn$result.matrix,file="clipboard")
print(nn$result.matrix)
cat(' * ---------------------------------------------------------------- *\n')
cat(" *   Launch Excel and paste the result.matrix there.\n")
cat(" *         then hit the Enter Key to continue\n")
cat(' * ---------------------------------------------------------------- *\n')
dummy<-readline()

ourMax<-apply(iris[,-5],2,max)
ourMin<-apply(iris[,-5],2,min)
k<-data.frame(ourMax,ourMin)
colnames(k)<-c("max","min")
cat(' * ---------------------------------------------------------------- *\n')
cat(" *   Paste the max and min values for 4 variables to Excel.\n")
cat(' * ---------------------------------------------------------------- *\n')
write.csv(k,file="clipboard")
cat(' * ---------------------------------------------------------------- *\n')
plot(nn)

}
