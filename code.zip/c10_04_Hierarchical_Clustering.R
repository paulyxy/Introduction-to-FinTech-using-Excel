

.hierarchicalCluste<-function(){

   library(stats)
   #data <- matrix(rnorm(100), nrow = 50, ncol = 2)

   cat(" * ------------------------------------------- *\n")
   cat(" * Objective: generate a Dendrogram by using   *\n")
   cat("              a set of random numbers from a   *\n")
   cat(" *            standard normal distribution     *\n")
   cat(" * ------------------------------------------- *\n")
   cat(" * Step 1: input a random seed \n")
   seed<-as.numeric(readline())
   set.seed(seed)
  cat(" * Step 2: input the number of rows, such as 50 \n")
  n<-as.numeric(readline())
 data <- matrix(rnorm(n*2), nrow = n, ncol = 2)

   # Calculate distance matrix
   distance_matrix <- dist(data)
   # Perform hierarchical clustering
   hclust_result <- hclust(distance_matrix)

   # Plot the dendrogram
   plot(hclust_result, main = "Hierarchical Clustering Dendrogram", xlab = "", sub = "")
   cat(" * ------------------------------------------- *\n")
  
}

