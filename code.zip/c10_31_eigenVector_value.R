
# https://www.youtube.com/watch?v=eAcYYH9pKQ4


a<-c(1,2,4,4,1,2,5,4,8)

A<-matrix(a,3,3,byrow=T)

print(A)

> eigen(A)
eigen() decomposition
$values
[1] 1.517107e+00 4.828934e-01 1.110223e-16

$vectors
[,1]      [,2]       [,3]
[1,] 0.4215374  0.906811  0.0000000
[2,] 0.6412122 -0.298072 -0.7071068
[3,] 0.6412122 -0.298072  0.7071068

> print(A)
V1        V2        V3
1 0.6666667 0.2795426 0.2795426
2 0.2795426 0.6666667 0.6666667
3 0.2795426 0.6666667 0.6666667

A<-read.table("clipboard")





V <- eigen(A)$vectors
D <- diag(eigen(A)$values)
M1 <- V %*% D^2 %*% solve(V)
M2 <- A %*% A
all.equal(M1, M2) ## TRUE
