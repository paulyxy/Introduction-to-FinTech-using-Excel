.kmeans<-function(){
"Objective: draw a k-mean



" ;.zkmeans()}




.zkmeans<-function(){

  cat(" * ---------------------------------------------- *\n")
  cat(" * Objective: apply the K-means methdology        *\n")
  cat(" *           1) copy data                         *\n")
  cat(" *           2) enter n (number of centers)       *\n")
  cat(" * ---------------------------------------------- *\n")
  cat(" * Step 1: copy the data set                      *\n")
  cat(" * ---------------------------------------------- *\n")
  dummy<-readline()
  data<-read.table("clibpoard")

  data <- data.frame(
      x = rnorm(100, mean = rep(1:3, each = 50), sd = 0.5),
      y = rnorm(100, mean = rep(c(1, 2, 3), each = 50), sd = 0.5)
   )

   # Apply k-means clustering
   final<- kmeans(data, centers =n)
   cat(" * ---------------------------------------------- *\n")
   cat(" * K-Mean centers:                               *\n")
   print(final[2])
   cat(" * classification:                               *\n")
   print(final[1])
   #print(final)
   cat(" * ---------------------------------------------- *\n")
}

"
> totalSS<-final$totss
> ss2<-sum(final$withinss)
> (totalSS-ss2)/totalSS
[1] 0.5990443
"

