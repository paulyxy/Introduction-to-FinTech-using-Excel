.elbowPlot<-function(){

# Data
x <- c(1, 2, 3, 4, 5, 6, 7, 8)
y <- c(10, 8, 6.7, 5.3, 5.25, 5.2, 5.1, 5)

# Create the plot
y2<-"Sum of squared distances to centroids"
x2 = "Number of clusters (K)"
title<-"Elbow demonstration for an optimal K (K-means)"
plot(x,y,type="b",lwd=3,main=title,xlab=x2,ylab=y2)
}