.explainNeuralNetworks<-function(){

  
  hitEnter<-function(){  
     cat(' *   Hit the enter key to continue               *\n')
     dummy<-readline()
  }
  
  
  
cat(" *---------------------------------------------- *\n")  
cat(" *   Explain a simple example                    *\n")
hitEnter()

cat(" *---------------------------------------------- *\n")  
cat(" *   Input data: 3 columns                       *\n")
cat("     A   B     C                    *\n")  
cat(" ------  ---   --------               *\n")
cat("  hours  Part  Pass\n")
cat("  5	    3	     1\n")
cat("  2	    1	     0 \n")
cat("  8	    4      1 \n")
cat("  1	    0      0 \n")"

  
  
  
  
}