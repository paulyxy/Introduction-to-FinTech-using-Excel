.logisticRegression<-function(){
"Objective: run a logistic regression 
            need a package called 'clipr'
            install.packages('clipr')
            
            
            
Example 1> .show_default()

  

";.zlogisticRegression()}
.lr<<-.logisticRegression

.zlogisticRegression <- function(){

  cat(rep("\n",20))

 library(clipr)
  cat(" * ---------------------------------------------------- *\n")
  cat(" * Objective: run a logistic regression                 *\n")
  cat(" * ---------------------------------------------------- *\n")
  cat(" * Step 1: Copy your data then hit the Enter Key        *\n")
  dummy<-readline()
  data<-read_clip_tbl()
  
   # Load data
   # data2 <- ISLR::Default
   #data$default<-ifelse(data$default=="No",0,1)
  cat(" * ---The first several lines are shown below --------- *\n")
  print(head(data,3),row.names=F)
  cat(" * ---------------------------------------------------- *\n")
  cat(" * Step 2: which column is your target (y), such as 1   *\n")
  cat(" * ---------------------------------------------------- *\n")
#  print(head(data,3),row.names=F)
#  cat(" * ---------------------------------------------------- *\n")
  ii <- as.numeric(readline())
  data[,ii]<-as.factor(data[,ii])
  #data$default<-as.factor(data$default)


  cat(" * ---------------------------------------------------- *\n")
  cat(" * Step 3: Which columns are categorical variables      *\n")
  cat(" *         except the target column                     *\n")
  cat(" * ---------------------------------------------------- *\n")
 # print(head(data,3),row.names=F)
#  cat(" * ---------------------------------------------------- *\n")
  cat(" *         such as 1 2 3                                *\n")
  cat(" *         0 for nothing                                *\n")
  cat(" * ---------------------------------------------------- *\n")
  n <- scan()
  a<-length(n)
  if(a==0 | n==0){
       # do nothing
  }else{
     for(i in 1:n){
         data[,i]<-as.factor(data[,i])
     }
  }

  # data$student<-as.factor(data$student)
  cat(" * ---------------------------------------------------- *\n")
  cat(" * Step 4: Enter a random seed, such as 123             *\n")
  seed <- as.numeric(readline())
  set.seed(seed)
  
  cat(" * ---------------------------------------------------- *\n")
  cat(" * Step 5: Eenter a value for training such as 0.7      *\n")
  p <- as.numeric(readline())
  
  # Split data into training and testing sets
  sample <- sample(c(TRUE, FALSE), nrow(data), replace = TRUE, prob = c(p, 1 - p))
  train <- data[sample, ]
  test <- data[!sample, ]  
  
  # Fit logistic regression model

  names<-colnames(train)
  a<-names[ii]
  names<-names[-ii]
  b<-paste(names,collapse=" + ")

  aa<-paste(a," ~ ",b)
  #aa<-'default ~ student + balance + income'


  model <- glm(aa, family = "binomial", data = train)
  # model <- glm(default ~ student + balance + income, family = "binomial", data = train)
  
  options(scipen = 999) # Disable scientific notation for model summary
  # why??
  print(summary(model))      # View model summary
  
  cat(" * ---------------------------------------------------- *\n")
  cat(" * Step 6: Generating predictions and confusion matrix  *\n")
  
  # Generate predictions for the test set
  test$predicted_prob <- predict(model, newdata = test, type = "response")

  
  cat(" * ---------------------------------------------------- *\n")
  cat(" *    Enter a cut-off point such as 0.5                 *\n")
  cutoff<-as.numeric(readline())
  
  k<-toupper(unique(data[,ii]))
  kk<-grep("YES",k)

 if(length(kk)>0){
      # Convert probabilities to class predictions (default = "Yes" if prob > 0.5)
      test$predicted_class <- ifelse(test$predicted_prob > cutoff, "Yes", "No")
 }else{
      test$predicted_class <- ifelse(test$predicted_prob > cutoff, 1,0)
 }
 
  # Create a confusion matrix
  actual <- test$default
  predicted <- factor(test$predicted_class, levels = levels(actual))
  confusion_matrix <- table(Predicted = predicted, Actual = actual)
  
  
   cat(" * ---------------------------------------------------- *\n")
   print(confusion_matrix)
   # Calculate accuracy, sensitivity, and specificity
   accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
   cat(" * ---------------------------------------------------- *\n")
   cat(" *  Coufusion matrix:                                   *\n")
   cat(" * ---------------------------------------------------- *\n")
   cat("Accuracy:", round(accuracy, 4), "\n")
   sensitivity <- confusion_matrix["Yes", "Yes"] / sum(confusion_matrix[, "Yes"])
   specificity <- confusion_matrix["No", "No"] / sum(confusion_matrix[, "No"])
   cat("Sensitivity (True Positive Rate):", round(sensitivity, 4), "\n")
   cat("Specificity (True Negative Rate):", round(specificity, 4), "\n")
   cat(" * ---------------------------------------------------- *\n")
}



