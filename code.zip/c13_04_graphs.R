
library(neuralnet)

# Create a simple dataset
data <- data.frame(
  input = c(0, 1),
  output = c(0, 1)
)


nLayers<-0

# Train the neural network with one neuron
nn <- neuralnet(output ~ input, data, hidden =nLayers)

# Plot the neural network
plot(nn)
