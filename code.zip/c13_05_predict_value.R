

library(neuralnet)

# Step 1: Define the dataset
data <- data.frame(
  StudyHours = c(5, 2, 8, 1),
  ClassParticipation = c(3, 1, 4, 0),
  Target = c(1, 0, 1, 0)
)

# Normalize the input features to a range of 0 to 1
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}


data$StudyHours <- normalize(data$StudyHours)
data$ClassParticipation <- normalize(data$ClassParticipation)

# Step 2: Define the neural network structure and train the model
# We'll use one hidden layer with two neurons
nn <- neuralnet(Target ~ StudyHours + ClassParticipation, data = data, 
                hidden =1,                 # Two neurons in the hidden layer
                act.fct = "logistic",       # Sigmoid activation function
                linear.output = FALSE,      # For binary output
                stepmax = 1e5)              # Maximum steps to train


test_data <- data.frame(
  StudyHours = c(0.5714, 0.1429, 1, 0),
  ClassParticipation = c(0.1566, 0.1199, 0.1749, 0.1016)
)

# Get predictions
predictions <- compute(nn, test_data)
predicted_values <- round(predictions$net.result)  # Round to binary

print("Predicted Values (Pass = 1, Fail = 0):")
print(predicted_values)
