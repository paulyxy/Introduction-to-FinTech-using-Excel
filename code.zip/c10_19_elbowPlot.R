.elbowPlot<-function(){
  
library(ggplot2)
library(grid)  # For adding circles

# Data
x <- c(1, 2, 3, 4, 5, 6, 7, 8)
y <- c(10, 8, 6.7, 5.3, 5.25, 5.2, 5.1, 5)

# Create the plot
plot <- ggplot(data = data.frame(x, y), aes(x = x, y = y)) +
  geom_line(color = "blue", size = 2.5) +
  labs(x = "Number of clusters (K)", y = "Sum of squared distances to centroids") +
  annotate("text", x = 6, y = 9, label = "k=4", color = "black") +
  geom_segment(aes(x = 4.3, xend = 6, y = 6, yend = 9), arrow = arrow(length = unit(0.2, "cm")), color = "blue") +
  theme_minimal()

# Add circles
for (i in 1:length(x)) {
  plot <- plot + annotation_custom(grob = circleGrob(r = 0.03, gp = gpar(fill = "red")),
                                   xmin = x[i] - 0.25, xmax = x[i] + 0.25, 
                                   ymin = y[i] - 0.25, ymax = y[i] + 0.25)
}

# Display the plot
print(plot)
}

