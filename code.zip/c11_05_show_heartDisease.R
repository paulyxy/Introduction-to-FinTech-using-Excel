.show_heartDisease<-function(n=2){
"Objective: show the Heart Disease data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1> .show_heartDisease()
            age sex chest_pain_type resting_bp_s cholesterol fasting_blood_sugar resting_ecg max_heart_rate
          1  40   1               2          140         289                   0           0            172
          2  49   0               3          160         180                   0           0            156
             exercise_angina oldpeak st_slope target
          1               0       0        1      0
          2               0       1        2      1
 Example 2> .show_heartDisease(-2)
             age sex chest_pain_type resting_bp_s cholesterol fasting_blood_sugar resting_ecg max_heart_rate
        1189  57   0               2          130         236                   0           2            174
        1190  38   1               3          138         175                   0           0            173
              exercise_angina oldpeak st_slope target
        1189               0       0        2      1
        1190               0       0        1      0

 Example 3>.show_heartDiseases(0)
            Launch Excel and paste

https://raw.githubusercontent.com/rikhuijzer/heart-disease-dataset/refs/heads/main/heart-disease-dataset.csv
";.zshow_heartDisease(n)}

.zshow_heartDisease<-function(n){

      if(exists('.heartDiseaseData')==FALSE){
      infile<-"http://datayyy.com/data_R/heartDisease.RData"
      load(url(infile))
      .heartDiseaseData<<-.x
    }
  
    .showNobs(.heartDiseaseData,n)
}
