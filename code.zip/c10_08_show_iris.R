.show_iris<-function(n=2){
" Objective: show the Iris data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1> .show_iris()
            sepal_length sepal_width petal_length petal_width       class
         1          5.1         3.5          1.4         0.2 Iris-setosa
         2          4.9         3.0          1.4         0.2 Iris-setosa

Example 2>.show_iris(-3)
            sepal_length sepal_width petal_length petal_width          class
       148          6.5         3.0          5.2         2.0 Iris-virginica
       149          6.2         3.4          5.4         2.3 Iris-virginica
       150          5.9         3.0          5.1         1.8 Iris-virginica
     
 Example 3>.show_iris(0)
            Launch Excel and paste

";.zshow_iris(n)}

.zshow_iris<-function(n){
  if(exists('.irisData')==FALSE){
    .infile<-"http://datayyy.com/data_R/iris.RData"
    .irisData<<-get(load(url(.infile)))
  }
  .showNobs(.irisData,n)
}




