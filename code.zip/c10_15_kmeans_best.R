.kmeans<-function(){
"Objective: draw a k-mean



" ;.zkmeans()}

.zkmeans<-function(){
  cat(" * ------------------------------------------------- *\n")
  cat(" * Objective: apply the K-means methodology          *\n")
  cat(" *           1) copy data                            *\n")
  cat(" *           2) enter n (number of proposed centers) *\n")
  cat(" * ------------------------------------------------- *\n")
  cat(" * Step 1: copy the data set                         *\n")
  cat(" * ------------------------------------------------- *\n")
  dummy<-readline()
  
  data<-read.table(file="clipboard",header=TRUE)
  
  if(dim(data)[2]==1){
    data<-read.csv(file="clipboard",header=TRUE)
    
  }
  cat(" * Step 2: input n (number of proposed centers)      *\n")
  cat(" * ------------------------------------------------- *\n")
  n<-as.numeric(readline())
  
  # Apply k-means clustering
  final<- kmeans(data, centers =n)
   cat(" * ------------------------------------------------ *\n")
   cat(" * K-Mean centers:                                  *\n")
   print(final$centers)
   
   cat(" * ------------------------------------------------ *\n")
   cat(" * Cluster:                                         *\n")
   print(final$cluster)

      cat(" * ------------------------------------------------ *\n")
   cat(" * Winthin SS (Sum of Errors)                       *\n")
   print(final$withinss)
   cat(" * ------------------------------------------------ *\n")
   cat(" * Total SS (Sum of Errors)                         *\n")
   print(final$totss)
   #print(final)
   
   totalSS<-final$totss
   ss2<-sum(final$withinss)
   ratio<-(totalSS-ss2)/totalSS
   cat(" * ------------------------------------------------ *\n")
   cat(" *  The proportion of the total variance explained  *\n")
   print(ratio)
   cat(" * ------------------------------------------------ *\n")
 
   }
