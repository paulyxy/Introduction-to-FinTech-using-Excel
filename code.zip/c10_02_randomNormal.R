
.rnormNcentroids<-function(){
"Objective: draw a set of random number from a standard normal distribution

Example>  .kmeanPlot()
 
    * ------------------------------------------- *
    * Step 1: input a random seed 
    123
    * Step 2: input the number of centers 
    3
    * ------------------------------------------- *
  
" ;.zrnormNcentroids()}

.rnormNC<<-.rnormNcentroids

.zrnormNcentroids<-function(){


  cat(" * --------------------------------------------------- *\n")
  cat(" * Objective: draw random numbers for x and y columns  *\n")
  cat(" *            with 3, 4 or 5 colusters                 *\n")
  cat(" * --------------------------------------------------- *\n")
  cat(" * Step 1: input a random seed \n")
  seed<-as.numeric(readline())
  set.seed(seed)
  
  cat(" * Step 2: input the number of clusters, such as 2,3,4,5*\n")
  n1<-as.numeric(readline())
  
  cat(" * Step 3: input the number of rows, such as 100      *\n")
  n<-as.numeric(readline())
  
  
  cat(" * Step 4: input the standard deviation, such as 0.5   *\n")
  std<-as.numeric(readline())
  
  cat(" * ------------------------------------------- *\n")
  

  if(n1==2){
    a<-rep(1:2, each=50)
    b<-rep(c(1,2),each=50)
  }else if(n1==3){
    a<-rep(1:3, each=50)
    b<-rep(c(1,2,3),each=50)
  
  }else if(n1==4){
   a<-rep(1:4, each=50)
   b<-rep(c(1,2,3,4),each=50)
  }else{
    a<-rep(1:5, each=50)
    b<-rep(c(1,2,3,4,5),each=50)
  }
  
  data <- data.frame(
      x = rnorm(n, mean = a, sd = std),
      y = rnorm(n, mean = b, sd = std)
  )
  write(data,file="clipboards")
  cat(' * Launch your text editor and paste data there \n')
  
  

   
}


