

# Load the iris dataset
data(iris)

# Perform PCA on the numeric columns (excluding 'Species')
pca_result <- prcomp(iris[, 1:4], center = TRUE, scale. = TRUE)

# Summary of PCA to see the importance of each component
summary(pca_result)

# Extract the first 4 principal components (PC1, PC2, PC3, PC4)
pca_components <- pca_result$x
print(pca_components)
# Show the first few rows of the components
head(pca_components)

# If you want to add the PCA components to the original dataset:
iris_with_pca <- cbind(iris, pca_components)

# Show the updated dataset with PCA components
head(iris_with_pca)
