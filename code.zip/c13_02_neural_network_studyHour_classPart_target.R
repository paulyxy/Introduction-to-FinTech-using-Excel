# Install and load necessary package
if (!require(neuralnet)) install.packages("neuralnet", dependencies = TRUE)
library(neuralnet)

# Step 1: Define the dataset
data <- data.frame(
  StudyHours = c(5, 2, 8, 1),
  ClassParticipation = c(3, 1, 4, 0),
  Target = c(1, 0, 1, 0)
)

# Normalize the input features to a range of 0 to 1
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}
data$StudyHours <- normalize(data$StudyHours)
data$ClassParticipation <- normalize(data$ClassParticipation)

# Step 2: Define the neural network structure and train the model
# We'll use one hidden layer with two neurons
nn <- neuralnet(Target ~ StudyHours + ClassParticipation, data = data, 
                hidden = 2,                 # Two neurons in the hidden layer
                act.fct = "logistic",       # Sigmoid activation function
                linear.output = FALSE,      # For binary output
                stepmax = 1e5)              # Maximum steps to train

# Step 3: Visualize the neural network structure
plot(nn,lwd=4)

# Step 4: Test the neural network with the same dataset
# Compute the output of the neural network for the input data
predictions <- compute(nn, data[, c("StudyHours", "ClassParticipation")])

# Step 5: Extract predicted values and round them to get binary output
predicted_values <- round(predictions$net.result)
print("Predicted Values (Pass = 1, Fail = 0):")
print(predicted_values)

# Optional: Check accuracy by comparing predictions to the target values
accuracy <- sum(predicted_values == data$Target) / nrow(data)
print(paste("Accuracy:", accuracy * 100, "%"))
