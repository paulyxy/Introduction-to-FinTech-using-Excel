# Load required packages
#if (!require(neuralnet)) install.packages("neuralnet", dependencies = TRUE)

.showAllSteps<-function(){

library(neuralnet)

  hitEnter<-function(){
    cat(" * ------------------------------------------------------------- *\n")
    cat(" *   Hit the Enter Key to continue \n")
    cat(" * ------------------------------------------------------------- *\n")
    dummy<-readline()    
  }

# Define sigmoid activation function and derivative
sigmoid <- function(x) { 1 / (1 + exp(-x)) }
sigmoid_derivative <- function(x) { x * (1 - x) }

# Define data
data <- data.frame(
  StudyHours = c(5, 2, 8, 1),
  ClassParticipation = c(3, 1, 4, 0),
  Target = c(1, 0, 1, 0)
)

cat(" * ------------------------------------------------------------- *\n")
cat(' *   input data is shown below                                   *\n')
print(data,row.names=F)
hitEnter()


# Normalize the input features
normalize <- function(x) { (x - min(x)) / (max(x) - min(x)) }
data$StudyHours <- normalize(data$StudyHours)
data$ClassParticipation <- normalize(data$ClassParticipation)

# Parameters
learning_rate <- 0.5
epochs <- 65

# Initialize weights randomly

cat(' * ------------------------------------------------------- *\n')
cat(" Enter a random see, such as 123\n")
seed<-as.numeric(readline())
set.seed(seed)


weights_input_hidden <- runif(3)  # 2 inputs + 1 bias

cat(' * ------------------------------------------------------- *\n')
cat("  weights input to hidden:")
print(weights_input_hidden)

weights_hidden_output <- runif(2) # 1 hidden neuron + 1 bias
cat("  weights hidden to output:")
print(weights_hidden_output)
hitEnter()

# Training loop
for (step in 1:epochs) {
  cat(' * ------------------------------------------------------- *\n')
  cat("Step", step, "\n")
  
  # Forward Pass
  for (i in 1:nrow(data)) {
    
    # Input data
    input <- as.numeric(data[i, c("StudyHours", "ClassParticipation")])
    target <- data$Target[i]
    
    # Hidden layer calculation
    hidden_input <- weights_input_hidden[1]+weights_input_hidden[2] * input[1] + 
    weights_input_hidden[3] * input[2]
    hidden_output <- sigmoid(hidden_input)
    
    # Output layer calculation
    output_input<-weights_hidden_output[1]+ weights_hidden_output[2] * hidden_output
    output <- sigmoid(output_input)
    
    # Error calculation
    error <- target - output
    cat("Error=target - output =:", error, "\n")
    
    # Backpropagation
    # Calculate gradients for output and hidden layers
    output_delta <- error * sigmoid_derivative(output)
    hidden_delta <- output_delta * weights_hidden_output[2] * sigmoid_derivative(hidden_output)
    
    # Update weights for hidden-output layer
    weights_hidden_output[1] <- weights_hidden_output[1] + learning_rate * output_delta * 1
    weights_hidden_output[2] <- weights_hidden_output[2] + learning_rate * output_delta * hidden_output
    
    # Update weights for input-hidden layer
    weights_input_hidden[1] <- weights_input_hidden[1] + learning_rate * hidden_delta * 1
    weights_input_hidden[2] <- weights_input_hidden[2] + learning_rate * hidden_delta * input[1]
    weights_input_hidden[3] <- weights_input_hidden[3] + learning_rate * hidden_delta * input[2]
    
    # Display weights and output for each step
    #print(t(data[i,]))
    cat("Weights Input to Hidden:", weights_input_hidden, "\n")
    cat("Weights Hidden to Output:", weights_hidden_output, "\n")
    cat("Predicted Output:", output, "\n\n")
  }
  
  # Wait for user to press Enter before next step
  readline(prompt = "Press [Enter] to continue to the next step")
   }
}
  