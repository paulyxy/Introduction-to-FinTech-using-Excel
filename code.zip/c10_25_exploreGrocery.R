.grocery<-function(){
"Objective: geneate a subset for furhter analysis using Excel
    1) data set used is Groceries Data Set
    2) total observations is 38,765
    3) the number of unique transaction is 14,963
    4) the number of items is 167
    5) Top 20 based on frequency are
      
      Assume that we choose top 5 items and the output forma is shown below. 
Transaction     	whole.milk	other.vegetables	rolls.buns	soda	yogurt
1000_15-03-2015	    1               0               0         0      1
1000_24-06-2014	    1               0	              0         0      0
1000_27-05-2015     0               0               0         1	     0
1001_07-02-2014	    1               0               1         0      0
1001_12-12-2014	    1               0               0         1      0
1001_20-01-2015	    0               0               0         1      0
1002_09-02-2014	    0               1               0         0      0
1002_26-04-2014	    1               0               0         0      0
                Item Freq
1          whole milk 2502
2    other vegetables 1898
3          rolls/buns 1716
4                soda 1514
5              yogurt 1334
6     root vegetables 1071
7      tropical fruit 1032
8       bottled water  933
9             sausage  924
10       citrus fruit  812
11             pastry  785
12          pip fruit  744
13      shopping bags  731
14        canned beer  717
15       bottled beer  687
16 whipped/sour cream  662
17         newspapers  596
18        frankfurter  580
19        brown bread  571
20      domestic eggs  566
";.zgrocery()}

.zgrocery<-function(){
  if(exists('.groceriesData')==FALSE){
       .infile<-"http://datayyy.com/i2ft/data/groceriesData.RData"
       .groceriesData<<-get(load(url(.infile)))
  }
  
  
  cat(' * ----------------------------------------------------- *\n')
  cat(' * Objective: explore the Groceries Data Set             *\n')
  cat(' * ----------------------------------------------------- *\n')
  cat(' *  Step 1: want to view the first and last three lines? *\n')
  cat(' *  1      yes                                           *\n')
  cat(' *  2      no                                            *\n')
  
  yes<-readline()
  
  if(yes=="1"){
     print(head(.groceriesData,3))
     print(tail(.groceriesData,3))
  }
  cat(' * ----------------------------------------------------- *\n')
  cat(' *  Step 2: combine the first and second items           *\n')
  cat(' *         see the first 3 lines below.                  *\n')
  cat(' * ----------------------------------------------------- *\n')
  
  .x<-.groceriesData
  
  .x<-.x[order(.x$Member_number,.x$Date),]
  
  a<-paste0(.x$Member_number,"_",.x$Date)
  data<-data.frame(a,.x$itemDescription)
  colnames(data)<-c("Transacton","Item")
  
  print(head(data,3))
  cat(' * ----------------------------------------------------- *\n')
  #cat(' *         Hit the Enter key to continue                 *\n')
  #dummy<-readline()
  
  uniqueTransactions<-unique(data$Transacton)
  n1<-length(uniqueTransactions)
  cat(' * ----------------------------------------------------- *\n')
  cat(' *  Step 3: Generate unique transactions                 *\n')
  cat(' *          do you want to print the first 3 lines?      *\n')
  cat(' *  1      yes                                           *\n')
  cat(' *  2      no                                            *\n')
  yes2<-readline()
  
  if(yes2=="1"){
    cat(' The number of unique transactions is',n1,"\n")
    cat(uniqueTransactions[1],"\n")
    cat(uniqueTransactions[2],"\n")
    cat(uniqueTransactions[3],"\n")
  }
  cat(' * ----------------------------------------------------- *\n')
  
  cat(' * ----------------------------------------------------- *\n')
  cat(' *  Step 4: Calculate the frequency table for items     *\n')
  
  aa<-data.frame(table(data$Item))
  uniqueItems<-aa[order(aa$Freq,decreasing=T),]
  colnames(uniqueItems)<-c("Item","Freq")
  rownames(uniqueItems)<-NULL
  
  cat(' *          Input the number of top items               *\n')
  n2<-as.numeric(readline())
  print(uniqueItems[1:n2,])
  cat(' * ----------------------------------------------------- *\n')
  
  cat(' * ----------------------------------------------------- *\n')
  cat(' *  Step 5: Generate an output with the following format *\n')
  cat(" *          assume that you choose 9 items               *\n")
  cat(' *    ID, whole milk,other vegetables, ..., item9        *\n')
  cat(" *           1     ,    0            , ...,    1         *\n")
  cat(' * ----------------------------------------------------- *\n')
  cat(" *       input the number of items:                      *\n")
  n3<-as.numeric(readline())
  
  n_items<-data.frame(uniqueItems$Item[1:n3])
  colnames(n_items)<-"Item"
  
  n4<-nrow(data)
  data$i<-1:n4
  
  data2<-merge(data,n_items)
  
  data3<-data2[order(data2$i),]
  data4<-data.frame(data3$Transacton,data3$Item)
  colnames(data4)<-c("Transaction","Item")
  
  uniqueT4<-unique(data4$Transaction)
  
  n5<-length(uniqueT4)
  
  zeros<-rep(0,n5*n3)
  
  final<-data.frame(matrix(zeros,n5,n3))
  for(i in 1:n5){
    #i<-1
    a<-uniqueT4[i]
    b<-data4[grep(a,data4$Transaction),]
    n6<-nrow(b)
    for(j in 1:n6){
        d<-b$Item[j]
        for(k in 1:n3){
             e<-n_items[k,1]
             if(d==e){
                  final[i,k]<-1
                  break
             }
        }
     }
  }
  colnames(final)<-t(n_items)
  final2<-data.frame(uniqueT4,final)
  
  names<-colnames(final2)
  names[1]<-'Transaction'
  colnames(final2)<-names
  
  write.csv(final2,file="clipboard-16384",row.names=F,quote=F)
  cat(' * Launch Excel and paste it there for further analysis  \n')
  
}

